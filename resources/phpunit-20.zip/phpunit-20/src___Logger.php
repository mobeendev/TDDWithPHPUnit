<?php

class Logger {
    public static function log($data)
    {
        echo $data.' logged!';
    }
}
